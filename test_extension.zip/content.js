// Content script for LinkedIn integration
console.log('[Job Finder Sync] Loaded extension content script');

// --- SESSION SYNCHRONIZATION FOR LOCALHOST ---
if (window.location.host.includes('localhost:3000')) {
  const syncSession = () => {
    // 1. Try to read from local storage (auth fallback)
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.includes('auth-token') || key.includes('supabase.auth.token'))) {
        try {
          const sessionData = JSON.parse(localStorage.getItem(key));
          if (sessionData && sessionData.access_token) {
            chrome.storage.local.set({ supabaseToken: sessionData.access_token });
            console.log('[Job Finder Sync] Local storage token synchronized!');
          }
        } catch (e) {}
      }
    }

    // 2. Try to read from hidden DOM token element (SSR or Client)
    const tokenEl = document.getElementById('jf-supabase-token') || document.getElementById('jf-supabase-token-client');
    if (tokenEl) {
      const token = tokenEl.innerText.trim();
      if (token) {
        chrome.storage.local.set({ supabaseToken: token });
        console.log('[Job Finder Sync] DOM token synchronized!');
      }
    }
  };
  
  syncSession();
  window.addEventListener('storage', syncSession);
  
  // Observe DOM changes to capture token once rendered by Next.js
  const observer = new MutationObserver(syncSession);
  observer.observe(document.documentElement, { childList: true, subtree: true });
}

// --- INTELLECTUAL EASY APPLY BUTTON SELECTOR ---
function getEasyApplyButton() {
  const buttons = document.querySelectorAll('button');
  for (const btn of buttons) {
    const text = btn.innerText ? btn.innerText.trim().toLowerCase() : '';
    const ariaLabel = btn.getAttribute('aria-label') ? btn.getAttribute('aria-label').toLowerCase() : '';
    
    // Strictly match Easy Apply labels, avoiding Premium upsells
    if (
      (text === 'easy apply' || text === 'kolay başvur' || ariaLabel.includes('easy apply')) && 
      !text.includes('premium') && 
      !ariaLabel.includes('premium')
    ) {
      return btn;
    }
  }

  // Fallback to class selector if text match fails
  const classBtn = document.querySelector('.jobs-apply-button');
  if (classBtn && !classBtn.innerText.toLowerCase().includes('premium')) {
    return classBtn;
  }

  return null;
}

// --- CENTRAL API REQUEST WRAPPER WITH BEARER AUTH ---
async function callAgentApi(path, options = {}) {
  const { serverUrl = 'http://localhost:3000' } = await chrome.storage.local.get('serverUrl');
  const { supabaseToken } = await chrome.storage.local.get('supabaseToken');

  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (supabaseToken) {
    headers['Authorization'] = `Bearer ${supabaseToken}`;
  }

  return fetch(`${serverUrl}${path}`, {
    ...options,
    headers,
    credentials: 'include'
  });
}

// --- PERIODIC CONTROLLER INJECTION ---
setInterval(() => {
  if (window.location.href.includes('/jobs/')) {
    injectJobSyncButton();
  }
  if (window.location.href.includes('/jobs/search') || window.location.href.includes('/jobs/collections')) {
    injectAgentToolbar();
  }
  if (window.location.href.includes('/messaging/')) {
    injectMessagingAssistant();
  }
}, 2000);

// --- 1. JOB DETAILS SCRAPER & INJECTOR ---
function injectJobSyncButton() {
  if (document.getElementById('job-finder-sync-btn')) return;

  const actionContainer = 
    document.querySelector('.jobs-apply-button--top-card') || 
    document.querySelector('.jobs-save-button') ||
    document.querySelector('.job-details-jobs-unified-top-card__container');

  if (!actionContainer) return;

  const syncBtn = document.createElement('button');
  syncBtn.id = 'job-finder-sync-btn';
  syncBtn.innerHTML = `
    <span class="sync-icon">✦</span>
    <span class="sync-text">Sync to Job Finder</span>
  `;
  syncBtn.className = 'job-finder-sync-action-button';

  syncBtn.addEventListener('click', async () => {
    syncBtn.disabled = true;
    syncBtn.querySelector('.sync-text').innerText = 'Syncing...';

    const jobTitle = (
      document.querySelector('.job-details-jobs-unified-top-card__job-title')?.innerText || 
      document.querySelector('h1')?.innerText || 
      'Unknown Role'
    ).trim();

    const companyName = (
      document.querySelector('.job-details-jobs-unified-top-card__company-name')?.innerText || 
      document.querySelector('.jobs-unified-top-card__company-name')?.innerText ||
      'Unknown Company'
    ).trim();

    const jobLink = window.location.href;

    try {
      const res = await callAgentApi('/api/applications/create-external', {
        method: 'POST',
        body: JSON.stringify({
          companyName,
          jobTitle,
          jobLink,
          status: 'applied',
          notes: 'Synced from LinkedIn Job Details Page.'
        })
      });

      const data = await res.json();

      if (res.ok) {
        syncBtn.querySelector('.sync-text').innerText = 'Synced Successfully!';
        syncBtn.style.background = '#22c55e';
      } else {
        throw new Error(data.error || 'Failed to sync');
      }
    } catch (err) {
      console.error('[Job Finder Sync] Error syncing job:', err);
      syncBtn.querySelector('.sync-text').innerText = 'Sync Failed (Click to retry)';
      syncBtn.disabled = false;
      alert(`Sync Failed: ${err.message || 'Please ensure you are logged into your Job Finder Agent dashboard.'}`);
    }
  });

  actionContainer.parentNode.insertBefore(syncBtn, actionContainer.nextSibling);
}

// --- 2. MESSAGING ASSISTANT ---
function injectMessagingAssistant() {
  if (document.getElementById('job-finder-messaging-panel')) return;

  const chatContainer = document.querySelector('.msg-form__left-actions');
  const chatInput = document.querySelector('.msg-form__contenteditable');

  if (!chatContainer || !chatInput) return;

  const assistantPanel = document.createElement('div');
  assistantPanel.id = 'job-finder-messaging-panel';
  assistantPanel.className = 'job-finder-messaging-panel';
  
  assistantPanel.innerHTML = `
    <button type="button" class="job-finder-action-pill" id="jf-btn-suggest">
      ✦ Suggest AI Reply
    </button>
    <button type="button" class="job-finder-action-pill" id="jf-btn-sync-chat">
      ✦ Save Recruiter details
    </button>
  `;

  chatContainer.parentNode.insertBefore(assistantPanel, chatContainer);

  // Suggest AI Reply listener
  document.getElementById('jf-btn-suggest').addEventListener('click', async () => {
    const suggestBtn = document.getElementById('jf-btn-suggest');
    suggestBtn.innerText = 'Drafting...';
    suggestBtn.disabled = true;

    const messageBubbles = document.querySelectorAll('.msg-s-event-listitem__body');
    let lastRecruiterMsg = '';
    if (messageBubbles.length > 0) {
      lastRecruiterMsg = messageBubbles[messageBubbles.length - 1].innerText;
    }

    try {
      const resumesRes = await callAgentApi('/api/resume/optimize', { method: 'GET' }).catch(() => null);
      let resumeContent = null;
      if (resumesRes && resumesRes.ok) {
        const resumes = await resumesRes.json();
        if (resumes.length > 0) resumeContent = resumes[0].content;
      }

      const replyRes = await callAgentApi('/api/applications/chat-reply', {
        method: 'POST',
        body: JSON.stringify({ recruiterMessage: lastRecruiterMsg, resumeContent })
      });

      const replyData = await replyRes.json();

      if (replyRes.ok) {
        chatInput.focus();
        document.execCommand('insertText', false, replyData.replyText);
        suggestBtn.innerText = '✦ Suggest AI Reply';
      } else {
        throw new Error(replyData.error || 'Failed to suggest reply');
      }
    } catch (err) {
      console.error('[Job Finder Sync] Error getting AI suggestions:', err);
      suggestBtn.innerText = '✦ Suggest AI Reply';
      alert(`AI Reply failed: ${err.message || 'Please log in to your Job Finder Agent dashboard.'}`);
    } finally {
      suggestBtn.disabled = false;
    }
  });

  // Sync recruiter details listener
  document.getElementById('jf-btn-sync-chat').addEventListener('click', async () => {
    const syncChatBtn = document.getElementById('jf-btn-sync-chat');
    syncChatBtn.innerText = 'Syncing...';
    syncChatBtn.disabled = true;

    const recruiterName = (
      document.querySelector('.msg-thread__link h2')?.innerText || 
      document.querySelector('.msg-entity-lockup__entity-title')?.innerText ||
      'Recruiter'
    ).trim();

    const companyGuess = prompt(`Enter company name for ${recruiterName}:`, '');
    if (!companyGuess) {
      syncChatBtn.innerText = '✦ Save Recruiter details';
      syncChatBtn.disabled = false;
      return;
    }

    const roleGuess = prompt(`Enter job title (e.g. Frontend Engineer):`, '');
    if (!roleGuess) {
      syncChatBtn.innerText = '✦ Save Recruiter details';
      syncChatBtn.disabled = false;
      return;
    }

    try {
      const res = await callAgentApi('/api/applications/create-external', {
        method: 'POST',
        body: JSON.stringify({
          companyName: companyGuess,
          jobTitle: roleGuess,
          status: 'interviewing',
          notes: `Recruiter Name: ${recruiterName}\nSynced from LinkedIn messaging thread.`
        })
      });

      if (res.ok) {
        syncChatBtn.innerText = 'Saved!';
        setTimeout(() => {
          syncChatBtn.innerText = '✦ Save Recruiter details';
          syncChatBtn.disabled = false;
        }, 2000);
      } else {
        const data = await res.json();
        throw new Error(data.error || 'Failed to sync');
      }
    } catch (err) {
      console.error('[Job Finder Sync] Error syncing chat details:', err);
      syncChatBtn.innerText = '✦ Save Recruiter details';
      syncChatBtn.disabled = false;
      alert(`Sync Failed: ${err.message}`);
    }
  });
}

// --- 3. HIGHLIGHT TO TRANSLATE TOOLTIP ---
let activeTrigger = null;
let activeTooltip = null;

function removeFloatingElements() {
  if (activeTrigger) {
    activeTrigger.remove();
    activeTrigger = null;
  }
  if (activeTooltip) {
    activeTooltip.remove();
    activeTooltip = null;
  }
}

document.addEventListener('mouseup', (e) => {
  if (e.target.closest('.jf-floating-translate-trigger') || e.target.closest('.jf-floating-translate-tooltip')) {
    return;
  }

  removeFloatingElements();

  const selection = window.getSelection();
  const selectedText = selection ? selection.toString().trim() : '';

  if (selectedText.length > 2) {
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    const trigger = document.createElement('button');
    trigger.className = 'jf-floating-translate-trigger';
    trigger.innerHTML = '✦ Translate';
    
    trigger.style.top = `${window.scrollY + rect.top - 32}px`;
    trigger.style.left = `${window.scrollX + rect.left + (rect.width / 2) - 40}px`;

    trigger.addEventListener('click', async (event) => {
      event.stopPropagation();
      trigger.innerText = 'Translating...';
      trigger.disabled = true;

      try {
        const res = await callAgentApi('/api/translation/translate', {
          method: 'POST',
          body: JSON.stringify({
            text: selectedText,
            sourceLang: 'auto-detect',
            targetLang: 'Azerbaijani (or English if source is Azerbaijani)'
          })
        });

        if (!res.ok) throw new Error('Translation failed');
        const data = await res.json();

        createTooltip(data.translatedText, rect);
        if (activeTrigger) {
          activeTrigger.remove();
          activeTrigger = null;
        }

      } catch (err) {
        console.error('[Job Finder Sync] Selection translation failed:', err);
        trigger.innerText = 'Error!';
        setTimeout(removeFloatingElements, 2000);
      }
    });

    document.body.appendChild(trigger);
    activeTrigger = trigger;
  }
});

function createTooltip(text, targetRect) {
  removeFloatingElements();

  const tooltip = document.createElement('div');
  tooltip.className = 'jf-floating-translate-tooltip animate-fade-in';
  tooltip.innerHTML = `
    <div class="jf-tooltip-header">
      <span class="jf-tooltip-title">✦ AI Translation</span>
      <button class="jf-tooltip-close">&times;</button>
    </div>
    <div class="jf-tooltip-content">${text}</div>
  `;

  tooltip.style.top = `${window.scrollY + targetRect.top - 110}px`;
  tooltip.style.left = `${window.scrollX + targetRect.left + (targetRect.width / 2) - 130}px`;

  tooltip.querySelector('.jf-tooltip-close').addEventListener('click', (e) => {
    e.stopPropagation();
    removeFloatingElements();
  });

  document.body.appendChild(tooltip);
  activeTooltip = tooltip;
}

// --- 4. COGNITIVE FORM EXTRACTOR & AUTO-FILL HELPERS ---
function extractFormFields(modal) {
  const fields = [];
  
  // 1. Text fields & Textareas
  const textInputs = modal.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea');
  textInputs.forEach(input => {
    const id = input.id || input.name || `text-${Math.random().toString(36).substr(2, 9)}`;
    input.setAttribute('data-jf-field-id', id);

    const labelEl = modal.querySelector(`label[for="${input.id}"]`) || input.closest('.fb-form-element, div')?.querySelector('label, span[class*="label"]');
    const label = labelEl ? labelEl.innerText.trim() : (input.getAttribute('aria-label') || 'Question');

    fields.push({
      id,
      label,
      type: input.tagName.toLowerCase() === 'textarea' ? 'textarea' : 'text',
      placeholder: input.placeholder || ''
    });
  });

  // 2. Select Dropdowns
  const selects = modal.querySelectorAll('select');
  selects.forEach(select => {
    const id = select.id || select.name || `select-${Math.random().toString(36).substr(2, 9)}`;
    select.setAttribute('data-jf-field-id', id);

    const labelEl = modal.querySelector(`label[for="${select.id}"]`) || select.closest('.fb-form-element, div')?.querySelector('label, span[class*="label"]');
    const label = labelEl ? labelEl.innerText.trim() : (select.getAttribute('aria-label') || 'Selection');

    const options = Array.from(select.options).map(opt => opt.text.trim()).filter(t => t);

    fields.push({
      id,
      label,
      type: 'select',
      options
    });
  });

  // 3. Radio groups
  const radioGroups = {};
  const radios = modal.querySelectorAll('input[type="radio"]');
  radios.forEach(radio => {
    const name = radio.name || 'radio-group';
    if (!radioGroups[name]) radioGroups[name] = [];
    radioGroups[name].push(radio);
  });

  Object.entries(radioGroups).forEach(([name, radioElements]) => {
    const id = `radio-${name}`;
    radioElements.forEach(r => r.setAttribute('data-jf-field-id', id));

    const parentContainer = radioElements[0].closest('fieldset, .fb-form-element, div[class*="group"]');
    const labelEl = parentContainer ? parentContainer.querySelector('legend, span[class*="legend"], span[class*="label"]') : null;
    const label = labelEl ? labelEl.innerText.trim() : `Select option for ${name}`;

    const options = radioElements.map(r => {
      const labelSibling = modal.querySelector(`label[for="${r.id}"]`) || r.nextElementSibling;
      return labelSibling ? labelSibling.innerText.trim() : 'Option';
    });

    fields.push({
      id,
      label,
      type: 'radio',
      options
    });
  });

  return fields;
}

function fillFormFields(modal, answers) {
  Object.entries(answers).forEach(([fieldId, decidedValue]) => {
    const elements = modal.querySelectorAll(`[data-jf-field-id="${fieldId}"]`);
    if (elements.length === 0) return;

    const firstElement = elements[0];
    const type = firstElement.getAttribute('type') || firstElement.tagName.toLowerCase();

    if (type === 'textarea' || type === 'text' || type === 'email' || type === 'tel' || firstElement.tagName.toLowerCase() === 'textarea') {
      firstElement.value = decidedValue;
      firstElement.dispatchEvent(new Event('input', { bubbles: true }));
      firstElement.dispatchEvent(new Event('change', { bubbles: true }));
    } 
    else if (firstElement.tagName.toLowerCase() === 'select') {
      const select = firstElement;
      for (let i = 0; i < select.options.length; i++) {
        if (select.options[i].text.trim().toLowerCase() === String(decidedValue).toLowerCase() ||
            select.options[i].value.toLowerCase() === String(decidedValue).toLowerCase()) {
          select.selectedIndex = i;
          select.dispatchEvent(new Event('change', { bubbles: true }));
          break;
        }
      }
    } 
    else if (type === 'radio') {
      elements.forEach(radio => {
        const labelSibling = modal.querySelector(`label[for="${radio.id}"]`) || radio.nextElementSibling;
        const optionText = labelSibling ? labelSibling.innerText.trim().toLowerCase() : '';
        if (optionText === String(decidedValue).toLowerCase() || String(decidedValue).toLowerCase().includes(optionText)) {
          radio.click();
          radio.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
    }
  });
}

// --- 5. FLOATING CAREER AI AGENT TOOLBAR & AUTO-APPLY ---
function injectAgentToolbar() {
  if (document.getElementById('job-finder-agent-toolbar')) return;

  const toolbar = document.createElement('div');
  toolbar.id = 'job-finder-agent-toolbar';
  
  toolbar.innerHTML = `
    <div style="font-size: 11px; font-weight: bold; color: #a78bfa; margin-bottom: 6px; display: flex; align-items: center; gap: 4px;">
      <span style="font-size: 13px;">✦</span> Career AI Agent Toolbar
    </div>
    <div id="jf-agent-status" style="font-size: 10px; color: #94a3b8; margin-bottom: 8px; font-family: monospace;">Status: Ready</div>
    <div style="display: flex; gap: 8px;">
      <button id="jf-btn-bulk-sync" style="background: #8b5cf6; border: none; border-radius: 8px; color: white; padding: 8px 12px; font-size: 11px; font-weight: bold; cursor: pointer; transition: all 0.2s; flex: 1;">
        Sync Results
      </button>
      <button id="jf-btn-auto-apply" style="background: #10b981; border: none; border-radius: 8px; color: white; padding: 8px 12px; font-size: 11px; font-weight: bold; cursor: pointer; transition: all 0.2s; flex: 1;">
        Auto-Apply
      </button>
    </div>
  `;

  Object.assign(toolbar.style, {
    position: 'fixed',
    bottom: '24px',
    left: '24px',
    zIndex: '9999',
    backgroundColor: '#0f172a',
    border: '1px solid rgba(139, 92, 246, 0.3)',
    borderRadius: '16px',
    padding: '14px',
    width: '260px',
    boxShadow: '0 10px 25px rgba(0, 0, 0, 0.5)',
    fontFamily: 'system-ui, -apple-system, sans-serif'
  });

  document.body.appendChild(toolbar);

  const syncBtn = document.getElementById('jf-btn-bulk-sync');
  const applyBtn = document.getElementById('jf-btn-auto-apply');
  const statusText = document.getElementById('jf-agent-status');

  syncBtn.addEventListener('mouseenter', () => syncBtn.style.backgroundColor = '#7c3aed');
  syncBtn.addEventListener('mouseleave', () => syncBtn.style.backgroundColor = '#8b5cf6');
  applyBtn.addEventListener('mouseenter', () => applyBtn.style.backgroundColor = '#059669');
  applyBtn.addEventListener('mouseleave', () => applyBtn.style.backgroundColor = '#10b981');

  // 1. Sync Search Results listener
  syncBtn.addEventListener('click', async () => {
    syncBtn.disabled = true;
    statusText.innerText = 'Scraping page...';

    const scrapedJobs = [];
    const jobLinks = document.querySelectorAll('a');
    
    jobLinks.forEach(linkEl => {
      const href = linkEl.getAttribute('href') || '';
      const idMatch = href.match(/\/jobs\/view\/(\d+)/) || href.match(/currentJobId=(\d+)/) || href.match(/\/jobs\/(\d+)/);
      const jobId = idMatch ? idMatch[1] : '';
      
      if (jobId) {
        const title = linkEl.innerText.trim();
        if (!title || title.length < 3) return;
        const lowerTitle = title.toLowerCase();
        if (
          lowerTitle.includes('view') || 
          lowerTitle === 'apply' || 
          lowerTitle === 'easy apply' || 
          lowerTitle === 'save' || 
          lowerTitle === 'dismiss' ||
          lowerTitle.includes('promoted')
        ) return;

        let company = 'Unknown Company';
        let location = 'Unknown Location';
        let parent = linkEl.parentElement;

        for (let i = 0; i < 6; i++) {
          if (!parent) break;
          const compEl = parent.querySelector('.job-card-container__company-name, .job-card-container__primary-description, .job-card-list__company-name, [class*="company-name"], [class*="company"]');
          const locEl = parent.querySelector('.job-card-container__metadata-item, .job-card-container__primary-description + span, .job-card-container__metadata-wrapper, .job-card-list__metadata-item, [class*="location"], [class*="metadata"]');
          
          if (compEl && company === 'Unknown Company') {
            company = compEl.innerText.trim().split('\n')[0].trim();
          }
          if (locEl && location === 'Unknown Location') {
            location = locEl.innerText.trim().split('\n')[0].trim();
          }
          if (company !== 'Unknown Company' && location !== 'Unknown Location') {
            break;
          }
          parent = parent.parentElement;
        }

        const cleanLink = `https://www.linkedin.com/jobs/view/${jobId}/`;

        if (!scrapedJobs.some(j => j.linkedin_job_id === jobId)) {
          scrapedJobs.push({
            linkedin_job_id: jobId,
            title: title,
            company: company,
            location: location,
            link: cleanLink
          });
        }
      }
    });

    if (scrapedJobs.length === 0) {
      statusText.innerText = 'Status: No jobs found on page';
      syncBtn.disabled = false;
      return;
    }

    statusText.innerText = `Status: Syncing ${scrapedJobs.length} jobs...`;

    try {
      const res = await callAgentApi('/api/applications/sync-bulk', {
        method: 'POST',
        body: JSON.stringify({ jobs: scrapedJobs })
      });

      if (res.ok) {
        statusText.innerText = 'Status: Successfully Synced!';
      } else {
        const data = await res.json();
        throw new Error(data.error || 'Failed to sync');
      }
    } catch (err) {
      console.error('[Job Finder Sync] Bulk sync error:', err);
      statusText.innerText = 'Status: Sync Failed';
    } finally {
      syncBtn.disabled = false;
    }
  });

  // 2. Auto-Apply to Easy Jobs listener
  applyBtn.addEventListener('click', async () => {
    applyBtn.disabled = true;
    syncBtn.disabled = true;
    statusText.innerText = 'Extracting job list...';

    const jobIds = [];
    const links = document.querySelectorAll('a');
    links.forEach(l => {
      const href = l.getAttribute('href') || '';
      const idMatch = href.match(/\/jobs\/view\/(\d+)/) || href.match(/currentJobId=(\d+)/) || href.match(/\/jobs\/(\d+)/);
      if (idMatch && idMatch[1] && !jobIds.includes(idMatch[1])) {
        jobIds.push(idMatch[1]);
      }
    });

    if (jobIds.length === 0) {
      statusText.innerText = 'Status: No jobs found to process';
      applyBtn.disabled = false;
      syncBtn.disabled = false;
      return;
    }

    statusText.innerText = `Status: Auto-applying (0 of ${jobIds.length})...`;
    
    let currentIndex = 0;

    const processNextJob = async () => {
      if (currentIndex >= jobIds.length) {
        statusText.innerText = 'Status: All jobs processed!';
        applyBtn.disabled = false;
        syncBtn.disabled = false;
        return;
      }

      const jobId = jobIds[currentIndex];
      statusText.innerText = `Status: Processing job ${currentIndex + 1}/${jobIds.length}...`;

      const linkEl = document.querySelector(`a[href*="${jobId}"]`);
      if (linkEl) {
        linkEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
        linkEl.click();
      }

      await new Promise(resolve => setTimeout(resolve, 2000));

      // Dismiss any blocking promotional/upsell modal (like "Try Premium")
      const premiumDismissBtn = 
        document.querySelector('.artdeco-modal__dismiss') || 
        document.querySelector('button[aria-label="Dismiss"]') || 
        document.querySelector('button[aria-label="Close"]') ||
        document.querySelector('.artdeco-modal button[class*="dismiss"]');

      if (premiumDismissBtn && !document.querySelector('.jobs-easy-apply-modal')) {
        console.log('[Job Finder Auto-Apply] Dismissing promotional/upsell modal.');
        premiumDismissBtn.click();
        await new Promise(resolve => setTimeout(resolve, 1500));
      }

      const easyApplyBtn = getEasyApplyButton();

      if (!easyApplyBtn) {
        console.log(`[Job Finder Auto-Apply] Job ${jobId} does not support Easy Apply. Skipping.`);
        currentIndex++;
        processNextJob();
        return;
      }

      easyApplyBtn.click();
      await new Promise(resolve => setTimeout(resolve, 2000));

      let modalOpen = true;
      let stepCounter = 0;
      let formErrorDetected = false;

      while (modalOpen && stepCounter < 10) {
        stepCounter++;
        const modal = document.querySelector('[role="dialog"], .jobs-easy-apply-modal, div[class*="easy-apply"]');
        if (!modal) {
          modalOpen = false;
          break;
        }

        // --- SUCCESS / THANK YOU SCREEN DETECTOR ---
        const modalText = modal.innerText ? modal.innerText.toLowerCase() : '';
        const isSuccessScreen = 
          modalText.includes('application sent') ||
          modalText.includes('thank you') ||
          modalText.includes('successfully applied') ||
          modalText.includes('applied!') ||
          modal.querySelector('.artdeco-inline-feedback--success') ||
          modal.querySelector('[class*="post-apply"]');

        if (isSuccessScreen) {
          console.log('[Job Finder Auto-Apply] Success screen detected! Closing modal.');
          const doneBtn = 
            modal.querySelector('button[aria-label*="Dismiss"]') || 
            modal.querySelector('button[aria-label*="Close"]') || 
            modal.querySelector('.artdeco-button--primary') ||
            modal.querySelector('button');
          if (doneBtn) {
            doneBtn.click();
          }
          modalOpen = false;
          formErrorDetected = false;
          break;
        }

        // --- DYNAMIC COGNITIVE AI AUTO-FILL ---
        const fields = extractFormFields(modal);
        if (fields.length > 0) {
          statusText.innerText = `Status: AI answering step ${stepCounter}...`;
          
          const jobTitle = (document.querySelector('h1')?.innerText || 'Easy Apply Role').trim();
          const companyName = (document.querySelector('.job-details-jobs-unified-top-card__company-name')?.innerText || 'LinkedIn Partner').trim();

          const fillRes = await callAgentApi('/api/applications/auto-fill', {
            method: 'POST',
            body: JSON.stringify({ fields, jobTitle, companyName })
          }).catch(() => null);

          if (fillRes && fillRes.ok) {
            const fillData = await fillRes.json();
            if (fillData.answers) {
              fillFormFields(modal, fillData.answers);
            }
          }
        }

        const primaryBtn = 
          modal.querySelector('button[aria-label*="Submit application"]') ||
          modal.querySelector('button[aria-label*="Submit"]') ||
          modal.querySelector('button[aria-label*="Review"]') ||
          modal.querySelector('button[aria-label*="Continue"]') ||
          modal.querySelector('button[aria-label*="next"]') ||
          modal.querySelector('button.jp-button--primary');

        if (primaryBtn) {
          primaryBtn.click();
          await new Promise(resolve => setTimeout(resolve, 2000));
        } else {
          formErrorDetected = true;
          break;
        }

        const modalStillExists = document.querySelector('[role="dialog"], .jobs-easy-apply-modal');
        if (!modalStillExists) {
          modalOpen = false;
          break;
        }

        const hasError = modal.querySelector('.artdeco-inline-feedback--error, [aria-invalid="true"], .fb-form-element__feedback');
        if (hasError) {
          formErrorDetected = true;
          statusText.innerText = 'Status: Paused (Input Required)';
          hasError.scrollIntoView({ block: 'center', behavior: 'smooth' });
          break;
        }
      }

      if (formErrorDetected) {
        const resumeBtn = document.createElement('button');
        resumeBtn.id = 'jf-btn-resume-apply';
        resumeBtn.innerText = 'Resume Auto-Apply';
        Object.assign(resumeBtn.style, {
          backgroundColor: '#8b5cf6',
          border: 'none',
          borderRadius: '8px',
          color: 'white',
          padding: '4px 8px',
          fontSize: '10px',
          fontWeight: 'bold',
          cursor: 'pointer',
          marginTop: '6px',
          width: '100%'
        });

        toolbar.appendChild(resumeBtn);

        resumeBtn.addEventListener('click', () => {
          resumeBtn.remove();
          processNextJob();
        });
      } else {
        const jobTitle = (document.querySelector('h1')?.innerText || 'Easy Apply Role').trim();
        const companyName = (document.querySelector('.job-details-jobs-unified-top-card__company-name')?.innerText || 'LinkedIn Partner').trim();

        await callAgentApi('/api/applications/create-external', {
          method: 'POST',
          body: JSON.stringify({
            companyName,
            jobTitle,
            jobLink: `https://www.linkedin.com/jobs/view/${jobId}/`,
            status: 'applied',
            notes: 'Submitted automatically by AI Auto-Apply Agent.'
          })
        }).catch(err => console.error('Failed to sync auto-applied job:', err));

        currentIndex++;
        processNextJob();
      }
    };

    processNextJob();
  });
}
