// Fetch saved server URL and check connection status
document.addEventListener('DOMContentLoaded', async () => {
  const serverInput = document.getElementById('server-url');
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');

  // Load saved server URL
  const { serverUrl = 'http://localhost:3000' } = await chrome.storage.local.get('serverUrl');
  serverInput.value = serverUrl;

  const checkConnection = async (url) => {
    statusDot.className = 'status-dot';
    statusText.innerText = 'Checking...';

    try {
      // Fetch the create-external endpoint. It will return 401 or 400 if server is live,
      // or throw a network error if offline.
      const res = await fetch(`${url}/api/applications/create-external`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}) // empty payload to trigger standard route handling
      });

      if (res.status === 401) {
        statusDot.className = 'status-dot'; // keep red
        statusText.innerText = 'Not Logged In';
      } else {
        statusDot.className = 'status-dot connected';
        statusText.innerText = 'Connected';
      }
    } catch (err) {
      statusDot.className = 'status-dot';
      statusText.innerText = 'Server Offline';
    }
  };

  // Run initial check
  await checkConnection(serverUrl);

  // Automatically read and sync the LinkedIn 'li_at' session cookie
  chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'li_at' }, async (cookie) => {
    if (cookie && cookie.value) {
      await chrome.storage.local.set({ linkedinLiAt: cookie.value });
      console.log('[Job Finder Sync] LinkedIn session cookie synced in storage.');

      const { supabaseToken } = await chrome.storage.local.get('supabaseToken');
      if (supabaseToken) {
        fetch(`${serverUrl}/api/agent/credentials`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseToken}`
          },
          body: JSON.stringify({ liAtCookie: cookie.value })
        })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            console.log('[Job Finder Sync] Session cookie synced to server!');
          }
        })
        .catch(err => console.error('Failed to sync session cookie to server:', err));
      }
    } else {
      console.warn('[Job Finder Sync] LinkedIn session cookie not found. Please log in to LinkedIn first.');
    }
  });

  // Re-check when URL changes
  serverInput.addEventListener('change', async (e) => {
    const newUrl = e.target.value.trim().replace(/\/$/, '');
    await chrome.storage.local.set({ serverUrl: newUrl });
    await checkConnection(newUrl);
  });
});
